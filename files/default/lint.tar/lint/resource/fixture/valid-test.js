var object = {
	bar: 'foo'
};
