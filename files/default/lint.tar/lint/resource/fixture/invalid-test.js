object = {
	bar: 'foo'
}
